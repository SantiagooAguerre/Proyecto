namespace Proyecto_Pokemon;

public interface IEfectos
{
    string Nombre { get; set; }
}